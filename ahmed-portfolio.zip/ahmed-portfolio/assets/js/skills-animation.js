/**
 * skills-animation.js
 * Animates the skill progress bars by setting their width
 * when they scroll into view. Reads the target percentage
 * from the data-pct attribute on each .skill-bar-fill element.
 */

(function initSkillsAnimation() {
  const fills = document.querySelectorAll('.skill-bar-fill');
  if (!fills.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;

        const fillEl = entry.target;
        const pct    = fillEl.dataset.pct || '0';

        // Trigger the CSS transition
        requestAnimationFrame(() => {
          fillEl.style.width = pct + '%';
        });

        observer.unobserve(fillEl);
      });
    },
    { threshold: 0.4 }
  );

  fills.forEach(el => observer.observe(el));
})();
